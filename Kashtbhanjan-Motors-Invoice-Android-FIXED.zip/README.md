# Kashtbhanjan Motors Invoice — Android build project

This is the Android wrapper for the existing Kashtbhanjan Motors Invoice HTML app. The existing UI, invoice/customer/dealer/report/backup/restore/WhatsApp/export/print-image functionality is retained; only the requested Android/build hardening and direct **Mark as Paid** action were added.

## Important upload rule
Extract this ZIP first, then upload the **contents** to the root of the GitHub repository. Do not upload the ZIP as a single repository file if you want GitHub Actions to detect `.github/workflows/build-apk.yml`.

Repository root should contain:
- `.github/workflows/build-apk.yml`
- `www/index.html`
- `package.json`
- `capacitor.config.json`
- `validate.mjs`
- `.gitignore`
- `README.md`

## Build hardening
GitHub Actions uses Capacitor 8, Node 22 and Java 21. Before Android generation it validates the HTML/inline JavaScript and required DOM references. It then installs `html2canvas@1.4.1` and replaces the CDN reference in the build workspace with a locally bundled copy so the APK does not depend on the CDN at runtime.

The workflow creates both a debug APK and an unsigned release APK. A proper signed release APK is produced only when the required signing secrets are configured.

## Release signing secrets
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Keep the keystore private. Do not commit it to the repository.

## Verification status
Static validation and JavaScript syntax validation pass locally. Final Android build/device verification must still be performed by GitHub Actions and on a real Android phone; no source-only check can honestly guarantee every external Android/WhatsApp/share behavior on every device.
