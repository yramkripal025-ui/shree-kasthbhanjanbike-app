import fs from 'node:fs';
import assert from 'node:assert/strict';

const root = new URL('.', import.meta.url).pathname;
const htmlPath = `${root}www/index.html`;
const html = fs.readFileSync(htmlPath, 'utf8');
assert(html.length > 100000, 'www/index.html looks incomplete');

const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
const inline = scripts.at(-1) || '';
assert(inline.length > 100000, 'main inline JavaScript is missing/incomplete');
new Function(inline);

const ids = new Set([...html.matchAll(/\bid=["']([^"']+)["']/g)].map(m => m[1]));
const refs = [...inline.matchAll(/\$\(["']([^"']+)["']\)/g)].map(m => m[1]);
const missing = [...new Set(refs.filter(id => !ids.has(id)))];
assert.equal(missing.length, 0, `Missing DOM ids referenced by JS: ${missing.join(', ')}`);

for (const f of ['package.json', 'capacitor.config.json', '.github/workflows/build-apk.yml']) {
  assert(fs.existsSync(`${root}${f}`), `Missing required file: ${f}`);
}

const pkg = JSON.parse(fs.readFileSync(`${root}package.json`, 'utf8'));
assert.equal(pkg.dependencies['@capacitor/android'], '8.5.2');
assert.equal(pkg.dependencies['@capacitor/core'], '8.5.2');
assert.equal(pkg.dependencies['html2canvas'], '1.4.1');
assert.equal(pkg.dependencies['jspdf'], '2.5.2');
assert(html.includes('html2canvas.min.js'), 'Local html2canvas script missing');
assert(html.includes('jspdf.umd.min.js'), 'Local jsPDF script missing');
assert(inline.includes('Filesystem'), 'Native file save integration missing');
assert(inline.includes('Share'), 'Native share integration missing');

console.log(`Validation OK: HTML ${html.length} bytes, inline JS ${inline.length} chars, DOM refs ${refs.length}, missing ${missing.length}`);
